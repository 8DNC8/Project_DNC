IfxSrc.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/Src/Std/IfxSrc.c :
IfxSrc.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Src\Std\IfxSrc.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Src\Std\IfxSrc.h :
IfxSrc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h" :
IfxSrc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxSrc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxSrc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxSrc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxSrc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxSrc.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxSrc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxSrc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxSrc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxSrc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
IfxSrc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
IfxSrc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
