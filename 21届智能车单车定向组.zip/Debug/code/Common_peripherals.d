Common_peripherals.o :	../code/Common_peripherals.c
../code/Common_peripherals.c :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_headfile.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_headfile.h" :
Common_peripherals.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
Common_peripherals.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
Common_peripherals.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
Common_peripherals.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
Common_peripherals.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h" :
Common_peripherals.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
Common_peripherals.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_typedef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_typedef.h" :
Common_peripherals.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
Common_peripherals.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_clock.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_clock.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_debug.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_debug.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_interrupt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_interrupt.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_fifo.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_fifo.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_font.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_font.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_function.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_function.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\user\isr_config.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\user\isr_config.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_adc.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_adc.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_delay.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_delay.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_dma.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_dma.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_exti.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_exti.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_encoder.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_encoder.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_exti.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_exti.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_flash.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_flash.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_gpio.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_gpio.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_pit.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_pit.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_pwm.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_pwm.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_soft_iic.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_soft_iic.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_spi.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_spi.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_soft_spi.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_soft_spi.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_uart.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_uart.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_timer.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_timer.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_absolute_encoder.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_absolute_encoder.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ble6a20.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ble6a20.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_bluetooth_ch9141.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_bluetooth_ch9141.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_gnss.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_gnss.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_camera.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_camera.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_uart.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_uart.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_type.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_type.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_dl1a.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_dl1a.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_dl1b.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_dl1b.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_icm20602.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_icm20602.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660ra.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660ra.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660rb.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660rb.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660rx.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660rx.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu963ra.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu963ra.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips114.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips114.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips200.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips200.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips200pro.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips200pro.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_key.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_key.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_menc15a.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_menc15a.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_mpu6050.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_mpu6050.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_mt9v03x.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_mt9v03x.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_oled.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_oled.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ov7725.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ov7725.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_scc8660.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_scc8660.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_tft180.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_tft180.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_tsl1401.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_tsl1401.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_uart_receiver.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_uart_receiver.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_virtual_oscilloscope.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_virtual_oscilloscope.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wifi_uart.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wifi_uart.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wifi_spi.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wifi_spi.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wireless_uart.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wireless_uart.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_components\seekfree_assistant.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_components\seekfree_assistant.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_components\seekfree_assistant_interface.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_components\seekfree_assistant_interface.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Common_peripherals.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Common_peripherals.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\small_driver_uart_control.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\small_driver_uart_control.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_headfile.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_headfile.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Ins.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Ins.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Menu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Menu.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Switch_mode.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Switch_mode.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Math_cal.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Math_cal.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Imu_init.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Imu_init.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_1.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_1.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_2.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_2.h" :
Common_peripherals.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_3.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_3.h" :
