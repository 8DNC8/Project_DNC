################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
"../code/Common_peripherals.c" \
"../code/Imu_init.c" \
"../code/Ins.c" \
"../code/KE_1.c" \
"../code/KE_2.c" \
"../code/KE_3.c" \
"../code/Math_cal.c" \
"../code/Menu.c" 

COMPILED_SRCS += \
"code/Common_peripherals.src" \
"code/Imu_init.src" \
"code/Ins.src" \
"code/KE_1.src" \
"code/KE_2.src" \
"code/KE_3.src" \
"code/Math_cal.src" \
"code/Menu.src" 

C_DEPS += \
"./code/Common_peripherals.d" \
"./code/Imu_init.d" \
"./code/Ins.d" \
"./code/KE_1.d" \
"./code/KE_2.d" \
"./code/KE_3.d" \
"./code/Math_cal.d" \
"./code/Menu.d" 

OBJS += \
"code/Common_peripherals.o" \
"code/Imu_init.o" \
"code/Ins.o" \
"code/KE_1.o" \
"code/KE_2.o" \
"code/KE_3.o" \
"code/Math_cal.o" \
"code/Menu.o" 


# Each subdirectory must supply rules for building sources it contributes
"code/Common_peripherals.src":"../code/Common_peripherals.c" "code/subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc26xb "-fC:/Users/65347/Desktop/Super_burger(1)/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
"code/Common_peripherals.o":"code/Common_peripherals.src" "code/subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"code/Imu_init.src":"../code/Imu_init.c" "code/subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc26xb "-fC:/Users/65347/Desktop/Super_burger(1)/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
"code/Imu_init.o":"code/Imu_init.src" "code/subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"code/Ins.src":"../code/Ins.c" "code/subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc26xb "-fC:/Users/65347/Desktop/Super_burger(1)/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
"code/Ins.o":"code/Ins.src" "code/subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"code/KE_1.src":"../code/KE_1.c" "code/subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc26xb "-fC:/Users/65347/Desktop/Super_burger(1)/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
"code/KE_1.o":"code/KE_1.src" "code/subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"code/KE_2.src":"../code/KE_2.c" "code/subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc26xb "-fC:/Users/65347/Desktop/Super_burger(1)/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
"code/KE_2.o":"code/KE_2.src" "code/subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"code/KE_3.src":"../code/KE_3.c" "code/subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc26xb "-fC:/Users/65347/Desktop/Super_burger(1)/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
"code/KE_3.o":"code/KE_3.src" "code/subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"code/Math_cal.src":"../code/Math_cal.c" "code/subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc26xb "-fC:/Users/65347/Desktop/Super_burger(1)/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
"code/Math_cal.o":"code/Math_cal.src" "code/subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"
"code/Menu.src":"../code/Menu.c" "code/subdir.mk"
	cctc -cs --dep-file="$*.d" --misrac-version=2012 -D__CPU__=tc26xb "-fC:/Users/65347/Desktop/Super_burger(1)/Debug/TASKING_C_C___Compiler-Include_paths__-I_.opt" --iso=99 --c++14 --language=+volatile --exceptions --anachronisms --fp-model=3 -O0 --tradeoff=4 --compact-max-size=200 -g -Wc-w544 -Wc-w557 -Ctc26xb -Y0 -N0 -Z0 -o "$@" "$<"
"code/Menu.o":"code/Menu.src" "code/subdir.mk"
	astc -Og -Os --no-warnings= --error-limit=42 -o  "$@" "$<"

clean: clean-code

clean-code:
	-$(RM) ./code/Common_peripherals.d ./code/Common_peripherals.o ./code/Common_peripherals.src ./code/Imu_init.d ./code/Imu_init.o ./code/Imu_init.src ./code/Ins.d ./code/Ins.o ./code/Ins.src ./code/KE_1.d ./code/KE_1.o ./code/KE_1.src ./code/KE_2.d ./code/KE_2.o ./code/KE_2.src ./code/KE_3.d ./code/KE_3.o ./code/KE_3.src ./code/Math_cal.d ./code/Math_cal.o ./code/Math_cal.src ./code/Menu.d ./code/Menu.o ./code/Menu.src

.PHONY: clean-code

