Math_cal.o :	../code/Math_cal.c
../code/Math_cal.c :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_headfile.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_headfile.h" :
Math_cal.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
Math_cal.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
Math_cal.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
Math_cal.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
Math_cal.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h" :
Math_cal.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
Math_cal.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_typedef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_typedef.h" :
Math_cal.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
Math_cal.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_clock.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_clock.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_debug.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_debug.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_interrupt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_interrupt.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_fifo.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_fifo.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_font.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_font.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_function.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_function.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\user\isr_config.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\user\isr_config.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_adc.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_adc.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_delay.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_delay.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_dma.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_dma.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_exti.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_exti.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_encoder.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_encoder.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_exti.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_exti.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_flash.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_flash.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_gpio.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_gpio.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_pit.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_pit.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_pwm.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_pwm.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_soft_iic.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_soft_iic.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_spi.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_spi.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_soft_spi.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_soft_spi.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_uart.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_uart.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_timer.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_timer.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_absolute_encoder.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_absolute_encoder.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ble6a20.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ble6a20.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_bluetooth_ch9141.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_bluetooth_ch9141.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_gnss.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_gnss.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_camera.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_camera.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_uart.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_uart.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_type.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_type.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_dl1a.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_dl1a.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_dl1b.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_dl1b.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_icm20602.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_icm20602.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660ra.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660ra.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660rb.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660rb.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660rx.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660rx.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu963ra.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu963ra.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips114.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips114.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips200.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips200.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips200pro.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips200pro.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_key.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_key.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_menc15a.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_menc15a.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_mpu6050.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_mpu6050.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_mt9v03x.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_mt9v03x.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_oled.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_oled.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ov7725.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ov7725.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_scc8660.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_scc8660.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_tft180.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_tft180.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_tsl1401.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_tsl1401.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_uart_receiver.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_uart_receiver.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_virtual_oscilloscope.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_virtual_oscilloscope.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wifi_uart.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wifi_uart.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wifi_spi.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wifi_spi.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wireless_uart.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wireless_uart.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_components\seekfree_assistant.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_components\seekfree_assistant.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_components\seekfree_assistant_interface.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_components\seekfree_assistant_interface.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Common_peripherals.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Common_peripherals.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\small_driver_uart_control.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\small_driver_uart_control.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_headfile.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_headfile.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Ins.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Ins.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Menu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Menu.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Switch_mode.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Switch_mode.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Math_cal.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Math_cal.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Imu_init.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Imu_init.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_1.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_1.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_2.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_2.h" :
Math_cal.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_3.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_3.h" :
