IfxMtu_cfg.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxMtu_cfg.c :
IfxMtu_cfg.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxMtu_cfg.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxMtu_cfg.h :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxMtu_cfg.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMtu_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMtu_reg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMtu_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMtu_regdef.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMc_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMc_reg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMc_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMc_regdef.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Mtu\Std\IfxMtu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Mtu\Std\IfxMtu.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxMtu_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxMtu_cfg.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMc_bf.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxMc_bf.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxMtu_cfg.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
