IfxStdIf_DPipe.o :	../libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.c
../libraries/infineon_libraries/Service/CpuGeneric/StdIf/IfxStdIf_DPipe.c :
IfxStdIf_DPipe.o :	..\libraries\infineon_libraries\Service\CpuGeneric\StdIf\IfxStdIf_DPipe.h
..\libraries\infineon_libraries\Service\CpuGeneric\StdIf\IfxStdIf_DPipe.h :
IfxStdIf_DPipe.o :	..\libraries\infineon_libraries\Service\CpuGeneric\StdIf\IfxStdIf.h
..\libraries\infineon_libraries\Service\CpuGeneric\StdIf\IfxStdIf.h :
IfxStdIf_DPipe.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxStdIf_DPipe.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxStdIf_DPipe.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxStdIf_DPipe.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxStdIf_DPipe.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxStdIf_DPipe.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxStdIf_DPipe.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxStdIf_DPipe.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
IfxStdIf_DPipe.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
IfxStdIf_DPipe.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
IfxStdIf_DPipe.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
