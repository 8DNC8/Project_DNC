Assert.o :	../libraries/infineon_libraries/Service/CpuGeneric/SysSe/Bsp/Assert.c
../libraries/infineon_libraries/Service/CpuGeneric/SysSe/Bsp/Assert.c :
Assert.o :	..\libraries\infineon_libraries\Service\CpuGeneric\SysSe\Bsp\Assert.h
..\libraries\infineon_libraries\Service\CpuGeneric\SysSe\Bsp\Assert.h :
Assert.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Assert.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
Assert.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Assert.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
Assert.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
Assert.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
Assert.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
Assert.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
