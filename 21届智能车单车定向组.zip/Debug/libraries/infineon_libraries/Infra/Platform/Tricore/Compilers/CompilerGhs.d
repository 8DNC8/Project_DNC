CompilerGhs.o :	../libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.c
../libraries/infineon_libraries/Infra/Platform/Tricore/Compilers/CompilerGhs.c :
CompilerGhs.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
CompilerGhs.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
CompilerGhs.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
CompilerGhs.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
CompilerGhs.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
CompilerGhs.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
CompilerGhs.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
CompilerGhs.o :	..\libraries\infineon_libraries\Infra\Platform\Tricore\Compilers\Compilers.h
..\libraries\infineon_libraries\Infra\Platform\Tricore\Compilers\Compilers.h :
