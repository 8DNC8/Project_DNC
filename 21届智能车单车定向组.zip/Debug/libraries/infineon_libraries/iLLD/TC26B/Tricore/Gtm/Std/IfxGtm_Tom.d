IfxGtm_Tom.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/Gtm/Std/IfxGtm_Tom.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/Gtm/Std/IfxGtm_Tom.c :
IfxGtm_Tom.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Gtm\Std\IfxGtm_Tom.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Gtm\Std\IfxGtm_Tom.h :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxGtm_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxGtm_cfg.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxGtm_Tom.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxGtm_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxGtm_reg.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxGtm_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxGtm_regdef.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxGtm_Tom.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Gtm\Std\IfxGtm.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Gtm\Std\IfxGtm.h :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxGtm_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxGtm_cfg.h" :
IfxGtm_Tom.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Gtm\Std\IfxGtm_Tbu.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Gtm\Std\IfxGtm_Tbu.h :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxGtm_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxGtm_cfg.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxGtm_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxGtm_bf.h" :
IfxGtm_Tom.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Gtm\Std\IfxGtm_Cmu.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Gtm\Std\IfxGtm_Cmu.h :
IfxGtm_Tom.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxGtm_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxGtm_cfg.h" :
