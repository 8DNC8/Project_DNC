IfxHssl_cfg.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Impl/IfxHssl_cfg.c :
IfxHssl_cfg.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxHssl_cfg.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Impl\IfxHssl_cfg.h :
IfxHssl_cfg.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxHssl_cfg.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxHssl_cfg.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxHssl_cfg.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxHssl_cfg.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxHssl_cfg.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxHssl_cfg.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxHssl_cfg.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHssl_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHssl_reg.h" :
IfxHssl_cfg.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHssl_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHssl_regdef.h" :
IfxHssl_cfg.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
IfxHssl_cfg.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHsct_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHsct_reg.h" :
IfxHssl_cfg.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHsct_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxHsct_regdef.h" :
