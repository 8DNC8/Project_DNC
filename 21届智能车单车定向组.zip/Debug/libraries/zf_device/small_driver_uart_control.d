small_driver_uart_control.o :	../libraries/zf_device/small_driver_uart_control.c
../libraries/zf_device/small_driver_uart_control.c :
small_driver_uart_control.o :	..\libraries\zf_device\small_driver_uart_control.h
..\libraries\zf_device\small_driver_uart_control.h :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_headfile.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_headfile.h" :
small_driver_uart_control.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
small_driver_uart_control.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
small_driver_uart_control.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
small_driver_uart_control.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
small_driver_uart_control.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h" :
small_driver_uart_control.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
small_driver_uart_control.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_typedef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_typedef.h" :
small_driver_uart_control.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
small_driver_uart_control.o :	"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"D:\infeling\AURIX-Studio-1.10.28\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_clock.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_clock.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_debug.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_debug.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_interrupt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_interrupt.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_fifo.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_fifo.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_font.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_font.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_function.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_function.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\user\isr_config.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\user\isr_config.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_adc.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_adc.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_delay.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_delay.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_dma.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_dma.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_exti.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_exti.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_encoder.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_encoder.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_exti.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_exti.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_flash.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_flash.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_gpio.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_gpio.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_pit.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_pit.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_pwm.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_pwm.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_soft_iic.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_soft_iic.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_spi.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_spi.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_soft_spi.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_soft_spi.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_uart.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_uart.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_timer.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_timer.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_absolute_encoder.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_absolute_encoder.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ble6a20.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ble6a20.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_bluetooth_ch9141.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_bluetooth_ch9141.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_gnss.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_gnss.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_camera.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_camera.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_uart.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_driver\zf_driver_uart.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_type.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_type.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_dl1a.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_dl1a.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_dl1b.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_dl1b.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_icm20602.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_icm20602.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660ra.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660ra.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660rb.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660rb.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660rx.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu660rx.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu963ra.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_imu963ra.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips114.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips114.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips200.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips200.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips200pro.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ips200pro.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_key.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_key.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_menc15a.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_menc15a.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_mpu6050.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_mpu6050.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_mt9v03x.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_mt9v03x.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_oled.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_oled.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ov7725.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_ov7725.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_scc8660.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_scc8660.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_tft180.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_tft180.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_tsl1401.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_tsl1401.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_uart_receiver.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_uart_receiver.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_virtual_oscilloscope.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_virtual_oscilloscope.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wifi_uart.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wifi_uart.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wifi_spi.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wifi_spi.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wireless_uart.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\zf_device_wireless_uart.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_components\seekfree_assistant.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_components\seekfree_assistant.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_components\seekfree_assistant_interface.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_components\seekfree_assistant_interface.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Common_peripherals.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Common_peripherals.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\small_driver_uart_control.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_device\small_driver_uart_control.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Ins.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Ins.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Menu.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Menu.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Switch_mode.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Switch_mode.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_headfile.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\libraries\\zf_common\zf_common_headfile.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Math_cal.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Math_cal.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Imu_init.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\Imu_init.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_1.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_1.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_2.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_2.h" :
small_driver_uart_control.o :	"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_3.h"
"C:\\Users\\65347\\Desktop\\Super_burger(1)\\code\KE_3.h" :
