Common_peripherals.o :	../code/Common_peripherals.c
../code/Common_peripherals.c :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_headfile.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_headfile.h" :
Common_peripherals.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\math.h" :
Common_peripherals.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\typeinfo.h" :
Common_peripherals.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdio.h" :
Common_peripherals.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdarg.h" :
Common_peripherals.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdint.h" :
Common_peripherals.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdbool.h" :
Common_peripherals.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\string.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\ifxAsclin_reg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_regdef.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
Common_peripherals.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Stm\Std\IfxStm.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxStm_cfg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Ccu6\\Timer\IfxCcu6_Timer.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Ccu6\Std\IfxCcu6.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxCcu6_PinMap.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCcu6_cfg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\If\Ccu6If\Timer.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_typedef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_typedef.h" :
Common_peripherals.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stdlib.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\ifx_types.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Cpu\\Std\PLATFORM_TYPES.H" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_clock.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_clock.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_debug.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_debug.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_interrupt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_interrupt.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_fifo.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_fifo.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_font.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_font.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_function.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_function.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\user\isr_config.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\user\isr_config.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_adc.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_adc.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_delay.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_delay.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_dma.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_dma.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Dma\\Std\IfxDma.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxDma_cfg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_bf.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_reg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxDma_regdef.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_exti.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_exti.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Scu\\Std\IfxScuEru.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_encoder.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_encoder.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_exti.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_exti.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_flash.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_flash.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\_Impl\ifxFlash_cfg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_gpio.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_gpio.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Port\\Std\IFXPORT.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_pit.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_pit.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_pwm.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_pwm.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_soft_iic.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_soft_iic.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_spi.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_spi.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_soft_spi.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_soft_spi.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_uart.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_uart.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\\Asclin\\Asc\ifxAsclin_Asc.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Asclin\Std\IfxAsclin.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxAsclin_reg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxAsclin_PinMap.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxAsclin_cfg.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Lib\DataHandling\Ifx_Fifo.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\SysSe\Bsp\Bsp.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf_DPipe.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\StdIf\IfxStdIf.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_timer.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_timer.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_absolute_encoder.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_absolute_encoder.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_ble6a20.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_ble6a20.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_bluetooth_ch9141.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_bluetooth_ch9141.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_gnss.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_gnss.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_camera.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_camera.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_uart.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_driver\zf_driver_uart.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_type.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_type.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_dl1a.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_dl1a.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_dl1b.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_dl1b.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_icm20602.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_icm20602.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_imu660ra.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_imu660ra.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_imu660rb.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_imu660rb.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_imu660rx.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_imu660rx.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_imu963ra.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_imu963ra.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_ips114.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_ips114.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_ips200.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_ips200.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_ips200pro.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_ips200pro.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_key.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_key.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_menc15a.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_menc15a.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_mpu6050.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_mpu6050.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_mt9v03x.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_mt9v03x.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_oled.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_oled.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_ov7725.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_ov7725.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_scc8660.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_scc8660.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_tft180.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_tft180.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_tsl1401.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_tsl1401.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_uart_receiver.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_uart_receiver.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_virtual_oscilloscope.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_virtual_oscilloscope.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_wifi_uart.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_wifi_uart.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_wifi_spi.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_wifi_spi.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_wireless_uart.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\zf_device_wireless_uart.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_components\seekfree_assistant.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_components\seekfree_assistant.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_components\seekfree_assistant_interface.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_components\seekfree_assistant_interface.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Imu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Imu.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Common_peripherals.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Common_peripherals.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\small_driver_uart_control.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_device\small_driver_uart_control.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_headfile.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\zf_common\zf_common_headfile.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Agorithm.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Agorithm.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Subject_1.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Subject_1.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Subject_2.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Subject_2.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Subject_3.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Subject_3.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Ins.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Ins.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Menu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\Menu.h" :
Common_peripherals.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\A_Mode_chage.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\code\A_Mode_chage.h" :
