IfxVadc.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Std/IfxVadc.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/Vadc/Std/IfxVadc.c :
IfxVadc.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Vadc\Std\IfxVadc.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\Vadc\Std\IfxVadc.h :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxVadc_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxVadc_cfg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Src\Std\IfxSrc.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxSrc_cfg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
IfxVadc.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_reg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxSrc_regdef.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\Ifx_TypesReg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxVadc_PinMap.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxVadc_PinMap.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxVadc_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxVadc_reg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxVadc_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxVadc_regdef.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxPort_cfg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_reg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxPort_regdef.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxScu_cfg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_bf.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_bf.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_reg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxScu_regdef.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.asm.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxVadc_bf.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxVadc_bf.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_Impl\IfxCpu_cfg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_reg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCpu_regdef.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_reg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxStm_regdef.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Service\\CpuGeneric\_Utilities\Ifx_Assert.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuCcu.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_reg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxFlash_regdef.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\_PinMap\IfxScu_PinMap.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Port\Std\IfxPort.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Scu\Std\IfxScuWdt.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_reg.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_regdef.h" :
IfxVadc.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Sfr\\TC26B\\_Reg\IfxCcu6_bf.h" :
