Ifx_CircularBuffer.o :	../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Lib/DataHandling/Ifx_CircularBuffer.c
../libraries/infineon_libraries/iLLD/TC26B/Tricore/_Lib/DataHandling/Ifx_CircularBuffer.c :
Ifx_CircularBuffer.o :	..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Lib\DataHandling\Ifx_CircularBuffer.h
..\libraries\infineon_libraries\iLLD\TC26B\Tricore\_Lib\DataHandling\Ifx_CircularBuffer.h :
Ifx_CircularBuffer.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_Intrinsics.h" :
Ifx_CircularBuffer.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_Types.h" :
Ifx_CircularBuffer.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\Compilers.h" :
Ifx_CircularBuffer.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Configurations\Ifx_Cfg.h" :
Ifx_CircularBuffer.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\Infra\\Platform\Tricore\Compilers\CompilerTasking.h" :
Ifx_CircularBuffer.o :	"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h"
"E:\ADS\AURIX-Studio-1.10.2\tools\Compilers\Tasking_1.1r8\ctc\include\stddef.h" :
Ifx_CircularBuffer.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Platform_Types.h" :
Ifx_CircularBuffer.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\Ifx_TypesTasking.h" :
Ifx_CircularBuffer.o :	"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h"
"F:\\Desktop\\AI_ADS_WS\\ORRN_TC264_ADS_DCDX_SW_V3.2\\libraries\\infineon_libraries\\iLLD\\TC26B\\Tricore\Cpu\Std\IfxCpu_IntrinsicsTasking.h" :
