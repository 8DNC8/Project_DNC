################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra_gen/common_data.c \
../ra_gen/hal_data.c \
../ra_gen/main.c \
../ra_gen/pin_data.c \
../ra_gen/vector_data.c 

C_DEPS += \
./ra_gen/common_data.d \
./ra_gen/hal_data.d \
./ra_gen/main.d \
./ra_gen/pin_data.d \
./ra_gen/vector_data.d 

OBJS += \
./ra_gen/common_data.o \
./ra_gen/hal_data.o \
./ra_gen/main.o \
./ra_gen/pin_data.o \
./ra_gen/vector_data.o 

SREC += \
RA8P1yaokong.srec 

MAP += \
RA8P1yaokong.map 


# Each subdirectory must supply rules for building sources it contributes
ra_gen/%.o: ../ra_gen/%.c
	$(file > $@.in,-mthumb -mfloat-abi=hard -mcpu=cortex-m85+nopacbti -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-strict-aliasing -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_CORE=CPU0 -D_RA_ORDINAL=1 -I"D:/e2studio/code/RA8P1yaokong/ra_gen" -I"." -I"D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp" -I"D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg" -I"D:/e2studio/code/RA8P1yaokong/src" -I"D:/e2studio/code/RA8P1yaokong/ra/fsp/inc" -I"D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api" -I"D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances" -I"D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include" -I"D:/e2studio/code/RA8P1yaokong/zf_common" -I"D:/e2studio/code/RA8P1yaokong/zf_driver" -I"D:/e2studio/code/RA8P1yaokong/zf_device" -std=c99 -Wno-stringop-overflow -Wno-format-truncation -flax-vector-conversions --param=min-pagesize=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

