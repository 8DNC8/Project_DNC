zf_device/zf_device_color_track.o: ../zf_device/zf_device_color_track.c \
 ../zf_device/zf_device_color_track.h \
 D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_typedef.h
../zf_device/zf_device_color_track.h:
D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_typedef.h:
