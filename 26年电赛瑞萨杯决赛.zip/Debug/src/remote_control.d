src/remote_control.o: ../src/remote_control.c ../src/remote_control.h \
 ../ra_gen/hal_data.h ../ra/fsp/inc/api/bsp_api.h \
 ../ra/fsp/inc/api/fsp_common_api.h ../ra/fsp/inc/fsp_version.h \
 ../ra_cfg/fsp_cfg/bsp/bsp_cfg.h ../ra_gen/bsp_clock_cfg.h \
 ../ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h \
 ../ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h \
 ../ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h \
 ../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/bsp_override.h \
 ../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/r_lpm_device_types.h \
 ../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/bsp_mcu_info.h \
 ../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/bsp_elc.h \
 ../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/bsp_feature.h \
 ../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/bsp_peripheral.h \
 ../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/r_adc_device_types.h \
 ../ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h \
 ../ra_cfg/fsp_cfg/bsp/board_cfg.h ../ra_gen/vector_data.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_exceptions.h \
 ../ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/renesas.h \
 ../ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 ../ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h \
 ../ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/R7KA8P1KF_core0.h \
 ../ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm85.h \
 ../ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h \
 ../ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 ../ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_mpu.h \
 ../ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_pmu.h \
 ../ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv7m_cachel1.h \
 ../ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/system.h \
 ../ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/system.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_common.h \
 ../ra/fsp/inc/api/../../inc/api/fsp_common_api.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_compiler_support.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_tfu.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_sdram.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_mmf.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_ipc.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_ospi_b.h bsp_linker_info.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_register_protection.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_irq.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_io.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_group_irq.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_clocks.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_module_stop.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_security.h \
 ../ra/fsp/inc/api/../../inc/fsp_features.h \
 ../ra/fsp/inc/api/fsp_common_api.h \
 ../ra/fsp/inc/api/../../inc/../../fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_delay.h \
 ../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_mcu_api.h \
 ../ra_gen/common_data.h ../ra/fsp/inc/instances/r_icu.h \
 ../ra/fsp/inc/api/r_external_irq_api.h ../ra/fsp/inc/api/bsp_api.h \
 ../ra/fsp/inc/instances/r_ioport.h ../ra/fsp/inc/api/r_ioport_api.h \
 ../ra_cfg/fsp_cfg/r_ioport_cfg.h ../ra_cfg/fsp_cfg/bsp/bsp_pin_cfg.h \
 ../ra/fsp/inc/instances/r_sci_b_spi.h ../ra/fsp/inc/api/r_spi_api.h \
 ../ra/fsp/inc/api/r_transfer_api.h ../ra/fsp/inc/api/r_capture_api.h \
 ../ra/fsp/inc/instances/r_ceu.h ../ra/fsp/inc/instances/r_ceu.h \
 ../ra/fsp/inc/instances/r_sci_b_uart.h ../ra/fsp/inc/api/r_uart_api.h \
 ../ra_cfg/fsp_cfg/r_sci_b_uart_cfg.h ../zf_common/zf_common_headfile.h \
 ../zf_common/zf_common_typedef.h ../zf_common/zf_common_debug.h \
 ../zf_common/zf_common_fifo.h ../zf_common/zf_common_font.h \
 ../zf_common/zf_common_function.h ../zf_driver/zf_driver_soft_iic.h \
 ../ra_gen/common_data.h ../zf_common/zf_common_typedef.h \
 ../zf_device/zf_device_ips200.h ../zf_device/zf_device_scc8660.h \
 ../zf_device/zf_device_color_track.h ../zf_device/zf_device_dl1b.h \
 ../zf_device/zf_device_imu660ra.h ../zf_device/zf_device_imu660rb.h \
 ../zf_device/zf_device_imu660rc.h ../zf_device/zf_device_imu963ra.h
../src/remote_control.h:
../ra_gen/hal_data.h:
../ra/fsp/inc/api/bsp_api.h:
../ra/fsp/inc/api/fsp_common_api.h:
../ra/fsp/inc/fsp_version.h:
../ra_cfg/fsp_cfg/bsp/bsp_cfg.h:
../ra_gen/bsp_clock_cfg.h:
../ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h:
../ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h:
../ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h:
../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/bsp_override.h:
../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/r_lpm_device_types.h:
../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/bsp_mcu_info.h:
../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/bsp_elc.h:
../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/bsp_feature.h:
../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/bsp_peripheral.h:
../ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra8p1/r_adc_device_types.h:
../ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h:
../ra_cfg/fsp_cfg/bsp/board_cfg.h:
../ra_gen/vector_data.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_exceptions.h:
../ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/renesas.h:
../ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
../ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h:
../ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/R7KA8P1KF_core0.h:
../ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm85.h:
../ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h:
../ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
../ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_mpu.h:
../ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_pmu.h:
../ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv7m_cachel1.h:
../ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/system.h:
../ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/system.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_common.h:
../ra/fsp/inc/api/../../inc/api/fsp_common_api.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_compiler_support.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_tfu.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_sdram.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_mmf.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_ipc.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_ospi_b.h:
bsp_linker_info.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_register_protection.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_irq.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_io.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_group_irq.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_clocks.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_module_stop.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_security.h:
../ra/fsp/inc/api/../../inc/fsp_features.h:
../ra/fsp/inc/api/fsp_common_api.h:
../ra/fsp/inc/api/../../inc/../../fsp/src/bsp/mcu/all/bsp_compiler_support.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_delay.h:
../ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_mcu_api.h:
../ra_gen/common_data.h:
../ra/fsp/inc/instances/r_icu.h:
../ra/fsp/inc/api/r_external_irq_api.h:
../ra/fsp/inc/api/bsp_api.h:
../ra/fsp/inc/instances/r_ioport.h:
../ra/fsp/inc/api/r_ioport_api.h:
../ra_cfg/fsp_cfg/r_ioport_cfg.h:
../ra_cfg/fsp_cfg/bsp/bsp_pin_cfg.h:
../ra/fsp/inc/instances/r_sci_b_spi.h:
../ra/fsp/inc/api/r_spi_api.h:
../ra/fsp/inc/api/r_transfer_api.h:
../ra/fsp/inc/api/r_capture_api.h:
../ra/fsp/inc/instances/r_ceu.h:
../ra/fsp/inc/instances/r_ceu.h:
../ra/fsp/inc/instances/r_sci_b_uart.h:
../ra/fsp/inc/api/r_uart_api.h:
../ra_cfg/fsp_cfg/r_sci_b_uart_cfg.h:
../zf_common/zf_common_headfile.h:
../zf_common/zf_common_typedef.h:
../zf_common/zf_common_debug.h:
../zf_common/zf_common_fifo.h:
../zf_common/zf_common_font.h:
../zf_common/zf_common_function.h:
../zf_driver/zf_driver_soft_iic.h:
../ra_gen/common_data.h:
../zf_common/zf_common_typedef.h:
../zf_device/zf_device_ips200.h:
../zf_device/zf_device_scc8660.h:
../zf_device/zf_device_color_track.h:
../zf_device/zf_device_dl1b.h:
../zf_device/zf_device_imu660ra.h:
../zf_device/zf_device_imu660rb.h:
../zf_device/zf_device_imu660rc.h:
../zf_device/zf_device_imu963ra.h:
