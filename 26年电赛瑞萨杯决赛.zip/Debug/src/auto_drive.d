src/auto_drive.o: ../src/auto_drive.c ../src/auto_drive.h \
 D:/e2studio/code/RA8P1yaokong/ra_gen/hal_data.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/bsp_api.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/fsp_common_api.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/fsp_version.h \
 D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/bsp_cfg.h \
 D:/e2studio/code/RA8P1yaokong/ra_gen/bsp_clock_cfg.h \
 D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h \
 D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h \
 D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/bsp_override.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/r_lpm_device_types.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/bsp_mcu_info.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/bsp_elc.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/bsp_feature.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/bsp_peripheral.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/r_adc_device_types.h \
 D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h \
 D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/board_cfg.h \
 D:/e2studio/code/RA8P1yaokong/ra_gen/vector_data.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_exceptions.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/renesas.h \
 D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/R7KA8P1KF_core0.h \
 D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm85.h \
 D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h \
 D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_mpu.h \
 D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_pmu.h \
 D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv7m_cachel1.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_common.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/fsp_common_api.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_tfu.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_sdram.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_mmf.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_ipc.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_ospi_b.h \
 bsp_linker_info.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_register_protection.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_irq.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_io.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_group_irq.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_clocks.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_module_stop.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_security.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/fsp_features.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/fsp_common_api.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_delay.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_mcu_api.h \
 D:/e2studio/code/RA8P1yaokong/ra_gen/common_data.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances/r_icu.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/r_external_irq_api.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/bsp_api.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances/r_ioport.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/r_ioport_api.h \
 D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/r_ioport_cfg.h \
 D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/bsp_pin_cfg.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances/r_sci_b_spi.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/r_spi_api.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/r_transfer_api.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/r_capture_api.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances/r_ceu.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances/r_ceu.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances/r_sci_b_uart.h \
 D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/r_uart_api.h \
 D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/r_sci_b_uart_cfg.h \
 ../src/balance_control.h \
 D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_headfile.h \
 D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_typedef.h \
 D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_debug.h \
 D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_fifo.h \
 D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_font.h \
 D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_function.h \
 D:/e2studio/code/RA8P1yaokong/zf_driver/zf_driver_soft_iic.h \
 D:/e2studio/code/RA8P1yaokong/ra_gen/common_data.h \
 D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_typedef.h \
 D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_ips200.h \
 D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_scc8660.h \
 D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_color_track.h \
 D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_dl1b.h \
 D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_imu660ra.h \
 D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_imu660rb.h \
 D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_imu660rc.h \
 D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_imu963ra.h \
 ../src/brushless_driver.h ../src/imu_process.h
../src/auto_drive.h:
D:/e2studio/code/RA8P1yaokong/ra_gen/hal_data.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/bsp_api.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/fsp_common_api.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/fsp_version.h:
D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/bsp_cfg.h:
D:/e2studio/code/RA8P1yaokong/ra_gen/bsp_clock_cfg.h:
D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h:
D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h:
D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/bsp_override.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/r_lpm_device_types.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/bsp_mcu_info.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/bsp_elc.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/bsp_feature.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/bsp_peripheral.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/ra8p1/r_adc_device_types.h:
D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h:
D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/board_cfg.h:
D:/e2studio/code/RA8P1yaokong/ra_gen/vector_data.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_exceptions.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/renesas.h:
D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/R7KA8P1KF_core0.h:
D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm85.h:
D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h:
D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_mpu.h:
D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_pmu.h:
D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv7m_cachel1.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_common.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/fsp_common_api.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_tfu.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_sdram.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_mmf.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_ipc.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_ospi_b.h:
bsp_linker_info.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_register_protection.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_irq.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_io.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_group_irq.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_clocks.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_module_stop.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_security.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/fsp_features.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/fsp_common_api.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_delay.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/src/bsp/mcu/all/bsp_mcu_api.h:
D:/e2studio/code/RA8P1yaokong/ra_gen/common_data.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances/r_icu.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/r_external_irq_api.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/bsp_api.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances/r_ioport.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/r_ioport_api.h:
D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/r_ioport_cfg.h:
D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp/bsp_pin_cfg.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances/r_sci_b_spi.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/r_spi_api.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/r_transfer_api.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/r_capture_api.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances/r_ceu.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances/r_ceu.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances/r_sci_b_uart.h:
D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api/r_uart_api.h:
D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/r_sci_b_uart_cfg.h:
../src/balance_control.h:
D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_headfile.h:
D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_typedef.h:
D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_debug.h:
D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_fifo.h:
D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_font.h:
D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_function.h:
D:/e2studio/code/RA8P1yaokong/zf_driver/zf_driver_soft_iic.h:
D:/e2studio/code/RA8P1yaokong/ra_gen/common_data.h:
D:/e2studio/code/RA8P1yaokong/zf_common/zf_common_typedef.h:
D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_ips200.h:
D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_scc8660.h:
D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_color_track.h:
D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_dl1b.h:
D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_imu660ra.h:
D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_imu660rb.h:
D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_imu660rc.h:
D:/e2studio/code/RA8P1yaokong/zf_device/zf_device_imu963ra.h:
../src/brushless_driver.h:
../src/imu_process.h:
