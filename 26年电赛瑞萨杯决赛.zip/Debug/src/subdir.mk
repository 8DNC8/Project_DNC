################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/auto_drive.c \
../src/balance_control.c \
../src/brushless_driver.c \
../src/camera_display.c \
../src/hal_entry.c \
../src/hal_warmstart.c \
../src/imu_angle_display.c \
../src/imu_process.c \
../src/key_tune.c \
../src/nag_flash.c \
../src/nag_navigation.c \
../src/remote_control.c \
../src/servo_hold.c \
../src/tof_follow.c \
../src/vest_follow.c \
../src/voice_control.c 

C_DEPS += \
./src/auto_drive.d \
./src/balance_control.d \
./src/brushless_driver.d \
./src/camera_display.d \
./src/hal_entry.d \
./src/hal_warmstart.d \
./src/imu_angle_display.d \
./src/imu_process.d \
./src/key_tune.d \
./src/nag_flash.d \
./src/nag_navigation.d \
./src/remote_control.d \
./src/servo_hold.d \
./src/tof_follow.d \
./src/vest_follow.d \
./src/voice_control.d 

OBJS += \
./src/auto_drive.o \
./src/balance_control.o \
./src/brushless_driver.o \
./src/camera_display.o \
./src/hal_entry.o \
./src/hal_warmstart.o \
./src/imu_angle_display.o \
./src/imu_process.o \
./src/key_tune.o \
./src/nag_flash.o \
./src/nag_navigation.o \
./src/remote_control.o \
./src/servo_hold.o \
./src/tof_follow.o \
./src/vest_follow.o \
./src/voice_control.o 

SREC += \
RA8P1yaokong.srec 

MAP += \
RA8P1yaokong.map 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	$(file > $@.in,-mthumb -mfloat-abi=hard -mcpu=cortex-m85+nopacbti -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-strict-aliasing -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_CORE=CPU0 -D_RA_ORDINAL=1 -I"D:/e2studio/code/RA8P1yaokong/ra_gen" -I"." -I"D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg/bsp" -I"D:/e2studio/code/RA8P1yaokong/ra_cfg/fsp_cfg" -I"D:/e2studio/code/RA8P1yaokong/src" -I"D:/e2studio/code/RA8P1yaokong/ra/fsp/inc" -I"D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/api" -I"D:/e2studio/code/RA8P1yaokong/ra/fsp/inc/instances" -I"D:/e2studio/code/RA8P1yaokong/ra/arm/CMSIS_6/CMSIS/Core/Include" -I"D:/e2studio/code/RA8P1yaokong/zf_common" -I"D:/e2studio/code/RA8P1yaokong/zf_driver" -I"D:/e2studio/code/RA8P1yaokong/zf_device" -std=c99 -Wno-stringop-overflow -Wno-format-truncation -flax-vector-conversions --param=min-pagesize=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

